#include "HardwareSerial.h"
#include "SmartElexPs2Shield.h"

SmartElexPs2Shield::SmartElexPs2Shield(uint8_t rxpin, uint8_t txpin)
{
  txpin_ = txpin;
  rxpin_ = rxpin;
}
SmartElexPs2Shield::SmartElexPs2Shield()
{
  txpin_ = 1;
  rxpin_ = 0;
}
void SmartElexPs2Shield::begin(uint32_t baudrate)
{
	if(rxpin_ == 0 && txpin_ == 1)
	{
		hardwareSerial = true;
		Serial.begin(baudrate);
		while(!Serial);
	}
	else
	{
		hardwareSerial = false;
		pinMode(rxpin_, INPUT);
		pinMode(txpin_, OUTPUT);
		SmartElexPs2Serial = new SoftwareSerial(rxpin_, txpin_);
		SmartElexPs2Serial->begin(baudrate);
	}
}
	
void SmartElexPs2Shield::SetController( uint8_t Controller_mode  )
{
	ControllerMode     = Controller_mode;
	if(hardwareSerial)
	{
		Serial.print("#");
		Serial.write(ControllerMode);
		Serial.println("*");
	}
	else
	{
		SmartElexPs2Serial-> print("#");
		SmartElexPs2Serial-> write(ControllerMode);
		SmartElexPs2Serial-> println("*");
	}
}

void SmartElexPs2Shield::VibrateMotors( uint8_t LeftValue, int RightValue )
{
	if(hardwareSerial)
	{
		Serial.print("&$");
		Serial.write(RightValue);
		Serial.write(LeftValue);
		Serial.println("$&");
	}
	else
	{
		SmartElexPs2Serial-> print("&$");
		SmartElexPs2Serial-> write(RightValue);
		SmartElexPs2Serial-> write(LeftValue);
		SmartElexPs2Serial-> println("$&");
	}
}

void SmartElexPs2Shield::ReadControllerButtons(void)
{
	
    Rx_Char_Index = 30;
    
	if(hardwareSerial)
	{
		while(Serial.available()>0)
		{
			char inChar = (char)Serial.read();
			Rx_String[Rx_Char_Index] = inChar;
			Rx_Char_Index++;
			if( Rx_String[Rx_Char_Index - 1] == '#' )
			{   
				if( Rx_String[Rx_Char_Index - 23] == '*' )
				{ 
					CurrentMode 	  =   Rx_String[Rx_Char_Index - 22];
					SELECT            =   Rx_String[Rx_Char_Index - 21] & 0x01;
					L3                = ((Rx_String[Rx_Char_Index - 21] & 0x02)>>1) ; 
					R3                = ((Rx_String[Rx_Char_Index - 21]  & 0x04)>>2) ; 
					START             = ((Rx_String[Rx_Char_Index - 21]  & 0x08)>>3) ;
					
					UP                = ((Rx_String[Rx_Char_Index - 21]  & 0x10)>>4) ;
					RIGHT             = ((Rx_String[Rx_Char_Index - 21]  & 0x20)>>5) ;
					DOWN              = ((Rx_String[Rx_Char_Index - 21]  & 0x40)>>6) ;
					LEFT              = ((Rx_String[Rx_Char_Index - 21]  & 0x80)>>7) ;
					
					L2                = ((Rx_String[Rx_Char_Index - 20]  & 0x01)) ;
					R2                = ((Rx_String[Rx_Char_Index - 20]   & 0x02)>>1) ;
					L1                = ((Rx_String[Rx_Char_Index - 20]   & 0x04)>>2) ;
					R1                = ((Rx_String[Rx_Char_Index - 20]   & 0x08)>>3) ;
					
					TRIANGLE          = ((Rx_String[Rx_Char_Index - 20]   & 0x10)>>4) ;
					CIRCLE            = ((Rx_String[Rx_Char_Index - 20]   & 0x20)>>5) ;
					CROSS             = ((Rx_String[Rx_Char_Index - 20]   & 0x40)>>6) ;
					SQUARE            = ((Rx_String[Rx_Char_Index - 20]   & 0x80)>>7) ;
					
					RIGHT_X_AXIS      =   Rx_String[Rx_Char_Index - 19]   ;
					RIGHT_Y_AXIS      =   Rx_String[Rx_Char_Index - 18]   ;
					LEFT_X_AXIS       =   Rx_String[Rx_Char_Index - 17]   ;
					LEFT_Y_AXIS       =   Rx_String[Rx_Char_Index - 16]   ;
					
					RIGHT_Pressure    =   Rx_String[Rx_Char_Index - 15]   ;
					LEFT_Pressure     =   Rx_String[Rx_Char_Index - 14]   ;
					UP_Pressure       =   Rx_String[Rx_Char_Index - 13]   ;
					DOWN_Pressure     =   Rx_String[Rx_Char_Index - 12]   ;
				  
					TRIANGLE_Pressure =   Rx_String[Rx_Char_Index - 11]   ;
					CIRCLE_Pressure   =   Rx_String[Rx_Char_Index - 10]   ;
					CROSS_Pressure    =   Rx_String[Rx_Char_Index - 9]   ;
					SQUARE_Pressure   =   Rx_String[Rx_Char_Index - 8]   ;
					
					L1_Pressure       =   Rx_String[Rx_Char_Index - 7]   ;
					R1_Pressure       =   Rx_String[Rx_Char_Index - 6]   ;
					L2_Pressure       =   Rx_String[Rx_Char_Index - 5]   ;
					R2_Pressure       =   Rx_String[Rx_Char_Index - 4]   ;
					LeftMotorVibrate  =   Rx_String[Rx_Char_Index - 3]   ;
					RightMotorVibrate =	  Rx_String[Rx_Char_Index - 2]   ;
					break;
				}
			}   
		}
	}
	else
	{
		while(SmartElexPs2Serial->available()>0)
		{
			char inChar = (char)SmartElexPs2Serial->read();
			Rx_String[Rx_Char_Index] = inChar;
			Rx_Char_Index++;
			if( Rx_String[Rx_Char_Index - 1] == '#' )
			{   
				if( Rx_String[Rx_Char_Index - 23] == '*' )
				{ 
					CurrentMode 	  =   Rx_String[Rx_Char_Index - 22];
					SELECT            =   Rx_String[Rx_Char_Index - 21] & 0x01;
					L3                = ((Rx_String[Rx_Char_Index - 21] & 0x02)>>1) ; 
					R3                = ((Rx_String[Rx_Char_Index - 21]  & 0x04)>>2) ; 
					START             = ((Rx_String[Rx_Char_Index - 21]  & 0x08)>>3) ;
					
					UP                = ((Rx_String[Rx_Char_Index - 21]  & 0x10)>>4) ;
					RIGHT             = ((Rx_String[Rx_Char_Index - 21]  & 0x20)>>5) ;
					DOWN              = ((Rx_String[Rx_Char_Index - 21]  & 0x40)>>6) ;
					LEFT              = ((Rx_String[Rx_Char_Index - 21]  & 0x80)>>7) ;
					
					L2                = ((Rx_String[Rx_Char_Index - 20]  & 0x01)) ;
					R2                = ((Rx_String[Rx_Char_Index - 20]   & 0x02)>>1) ;
					L1                = ((Rx_String[Rx_Char_Index - 20]   & 0x04)>>2) ;
					R1                = ((Rx_String[Rx_Char_Index - 20]   & 0x08)>>3) ;
					
					TRIANGLE          = ((Rx_String[Rx_Char_Index - 20]   & 0x10)>>4) ;
					CIRCLE            = ((Rx_String[Rx_Char_Index - 20]   & 0x20)>>5) ;
					CROSS             = ((Rx_String[Rx_Char_Index - 20]   & 0x40)>>6) ;
					SQUARE            = ((Rx_String[Rx_Char_Index - 20]   & 0x80)>>7) ;
					
					RIGHT_X_AXIS      =   Rx_String[Rx_Char_Index - 19]   ;
					RIGHT_Y_AXIS      =   Rx_String[Rx_Char_Index - 18]   ;
					LEFT_X_AXIS       =   Rx_String[Rx_Char_Index - 17]   ;
					LEFT_Y_AXIS       =   Rx_String[Rx_Char_Index - 16]   ;
					
					RIGHT_Pressure    =   Rx_String[Rx_Char_Index - 15]   ;
					LEFT_Pressure     =   Rx_String[Rx_Char_Index - 14]   ;
					UP_Pressure       =   Rx_String[Rx_Char_Index - 13]   ;
					DOWN_Pressure     =   Rx_String[Rx_Char_Index - 12]   ;
				  
					TRIANGLE_Pressure =   Rx_String[Rx_Char_Index - 11]   ;
					CIRCLE_Pressure   =   Rx_String[Rx_Char_Index - 10]   ;
					CROSS_Pressure    =   Rx_String[Rx_Char_Index - 9]   ;
					SQUARE_Pressure   =   Rx_String[Rx_Char_Index - 8]   ;
					
					L1_Pressure       =   Rx_String[Rx_Char_Index - 7]   ;
					R1_Pressure       =   Rx_String[Rx_Char_Index - 6]   ;
					L2_Pressure       =   Rx_String[Rx_Char_Index - 5]   ;
					R2_Pressure       =   Rx_String[Rx_Char_Index - 4]   ;
					LeftMotorVibrate  =   Rx_String[Rx_Char_Index - 3]   ;
					RightMotorVibrate =	  Rx_String[Rx_Char_Index - 2]   ;
					break;
				}
			}   
		}
	}
	
	

}





















