

#ifndef SmartElexPs2Shield_h
#define SmartElexPs2Shield_h

#include "Arduino.h"
#include <SoftwareSerial.h>

// Arduino Leonardo
#if defined (__AVR_ATmega32U4__)
  #define Serial Serial1
#else 
  #define Serial Serial
#endif

class SmartElexPs2Shield
{
	protected:
		boolean hardwareSerial;
		SoftwareSerial *SmartElexPs2Serial;
	public	:
		uint8_t   DigitalMode=1,Fixed_DigitalMode=2,AnalogMode=3,Fixed_AnalogMode=4;
		uint32_t  BaudRate=9600;
		uint8_t   ControllerMode,CurrentMode,SELECT,L3,R3,START,UP, RIGHT, DOWN, LEFT, L2, R2, L1, R1, TRIANGLE, CIRCLE, CROSS, SQUARE;
		uint8_t	  RIGHT_X_AXIS, RIGHT_Y_AXIS, LEFT_X_AXIS, LEFT_Y_AXIS, L3_Pressure, R3_Pressure, UP_Pressure, RIGHT_Pressure, DOWN_Pressure;
		uint8_t	  LEFT_Pressure, L2_Pressure, R2_Pressure, L1_Pressure, R1_Pressure, TRIANGLE_Pressure, CIRCLE_Pressure, CROSS_Pressure;
		uint8_t	  SQUARE_Pressure, LeftMotorVibrate, RightMotorVibrate,Rx_Arduino_Pin,Tx_Arduino_Pin;
		long int  Rx_Char_Index;
		int       nop=0;
        char      Rx_String[255];
		uint8_t   txpin_, rxpin_;
		
		
	//  Software Serial
		SmartElexPs2Shield(uint8_t rxpin, uint8_t txpin);
	//  Hardware Serial
		SmartElexPs2Shield();
		void begin(uint32_t baudrate);
		void SetController( uint8_t Controllermode );
		void VibrateMotors( uint8_t LeftValue, int RightValue );
		void ReadControllerButtons(void);
};

#endif


